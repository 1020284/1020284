# Learning Hub

Learning Hub is a multi-tool React web application that provides a suite of utilities designed to assist with everyday tasks and learning activities. The app features an intuitive dark-themed interface with a responsive layout and a non-interactive animated spiderweb canvas background for visual appeal.

## Features

- **Calculator**: Basic arithmetic calculator with keyboard support.
- **Current Time**: Displays your local current time updated every second.
- **Notepad**: Write, save, and load notes locally within your browser.
- **Random Number Generator**: Generate a random integer between a specified range.
- **Unit Converter**: Convert lengths (cm/inches) and weights (kg/pounds) with instant results.
- **Secret Code Input**: Input field that detects secret key combinations and triggers hidden alerts.
- **Markdown Preview**: Write Markdown text and see a live-rendered preview side-by-side.
- **Timezone Converter**: Convert datetime values between various IANA timezones.
- **Password Strength Checker**: Analyze password strength with real-time feedback and a strength meter.
- **Color Picker**: Choose colors with a native color input and see the hex value and preview.
- **Lorem Ipsum Generator**: Generate placeholder text paragraphs for design and testing.

## Prerequisites

- **Node.js** version 16 or higher (recommended LTS)
- npm (comes with Node.js)

You can verify your Node.js installation with:

    node -v
    npm -v

## Installation

1. Clone the repository or download the source code.

2. Install dependencies:

    npm install

## Configuration

This project includes an `.env.example` file for environment variables. Currently, it contains a placeholder for future API integration.

To configure environment variables, duplicate `.env.example` as `.env` and update variables as needed:

    cp .env.example .env

## Running the Application

### Development mode

Start a local development server with hot reloading:

    npm start

The app will open automatically in your default browser at `http://localhost:3000`.

### Production build

To build the app for production:

    npm run build

The output will be in the `dist` folder, ready to be served by any static file server.

## Usage

- Use the navigation menu at the top to switch between utilities.
- All inputs are fully accessible via keyboard.
- The **Notepad** autosaves your text to localStorage and allows manual save/load.
- The **Secret Code Input** listens for secret key combos like Shift+B, Shift+D, Shift+S, etc., to trigger hidden alerts.
- The **Markdown Preview** supports common Markdown syntax including headings, lists, links, and code blocks.
- The **Timezone Converter** uses IANA timezone names and supports several popular zones.
- The **Password Strength Checker** analyzes common password strength metrics and gives useful feedback.
- The **Color Picker** uses your browser's native color input for best compatibility.
- The **Lorem Ipsum Generator** lets you generate 1-10 paragraphs of placeholder text.

## Accessibility & Theming

- Dark theme with high contrast for comfortable viewing.
- Keyboard accessible navigation and form elements.
- Screen reader friendly ARIA roles and labels.
- Responsive layout for mobile and desktop screens.

## Troubleshooting

- If you experience issues starting the app, ensure your Node.js and npm versions meet the requirements.
- Clear your browser cache or try incognito mode if app state seems stale.
- Check your console for errors and ensure dependencies installed correctly (`npm install`).
- For localStorage issues in Notepad, ensure your browser allows localStorage usage.

## Project Structure

