import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import SecretCodeInput from '../components/SecretCodeInput';

describe('SecretCodeInput component', () => {
  beforeEach(() => {
    window.alert = jest.fn();
  });

  test('renders input and instructions', () => {
    render(<SecretCodeInput />);
    expect(screen.getByLabelText(/type secret key combinations/i)).toBeInTheDocument();
    expect(screen.getByText(/try pressing shift\+b/i)).toBeInTheDocument();
  });

  test('detects Shift+B and triggers alert', () => {
    render(<SecretCodeInput />);
    const input = screen.getByLabelText(/type secret key combinations/i);
    fireEvent.keyDown(input, { key: 'B', shiftKey: true });
    expect(window.alert).toHaveBeenCalledWith('Secret code Shift+B detected!');
  });

  test('detects Shift+D and triggers alert', () => {
    render(<SecretCodeInput />);
    const input = screen.getByLabelText(/type secret key combinations/i);
    fireEvent.keyDown(input, { key: 'D', shiftKey: true });
    expect(window.alert).toHaveBeenCalledWith('Secret code Shift+D detected!');
  });

  test('does not trigger alert for other keys', () => {
    render(<SecretCodeInput />);
    const input = screen.getByLabelText(/type secret key combinations/i);
    fireEvent.keyDown(input, { key: 'A', shiftKey: true });
    expect(window.alert).not.toHaveBeenCalled();
  });
});
