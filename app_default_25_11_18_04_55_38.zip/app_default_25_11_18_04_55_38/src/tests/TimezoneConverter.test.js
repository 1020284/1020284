import React from 'react';
import { render, screen, fireEvent, act } from '@testing-library/react';
import TimezoneConverter from '../components/TimezoneConverter';

describe('TimezoneConverter component', () => {
  test('renders inputs and selects', () => {
    render(<TimezoneConverter />);
    expect(screen.getByLabelText(/Enter date and time/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Source Timezone/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Target Timezone/i)).toBeInTheDocument();
  });

  test('shows error on invalid date input', () => {
    render(<TimezoneConverter />);
    const datetimeInput = screen.getByLabelText(/Enter date and time/i);
    fireEvent.change(datetimeInput, { target: { value: 'invalid-date' } });
    expect(screen.getByRole('alert')).toHaveTextContent(/invalid date\/time/i);
  });

  test('converts time correctly', () => {
    render(<TimezoneConverter />);
    const datetimeInput = screen.getByLabelText(/Enter date and time/i);
    const sourceSelect = screen.getByLabelText(/Source Timezone/i);
    const targetSelect = screen.getByLabelText(/Target Timezone/i);

    fireEvent.change(datetimeInput, { target: { value: '2024-06-20T12:00' } });
    fireEvent.change(sourceSelect, { target: { value: 'UTC' } });
    fireEvent.change(targetSelect, { target: { value: 'America/New_York' } });

    const convertedText = screen.queryByText(/Converted time/i);
    expect(convertedText).toBeInTheDocument();
    // We expect time to be 8:00 AM EDT on June 20 2024 (UTC-4)
    expect(convertedText.textContent).toMatch(/08:00:00/);
  });
});
