import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import ColorPicker from '../components/ColorPicker';

describe('ColorPicker component', () => {
  test('renders color input and displays selected color', () => {
    render(<ColorPicker />);
    const input = screen.getByLabelText(/color picker input/i);
    expect(input).toBeInTheDocument();
    expect(screen.getByText(/selected color/i)).toBeInTheDocument();
  });

  test('updates displayed color on input change', () => {
    render(<ColorPicker />);
    const input = screen.getByLabelText(/color picker input/i);
    fireEvent.change(input, { target: { value: '#ff0000' } });
    expect(screen.getByText(/#FF0000/i)).toBeInTheDocument();
  });
});
