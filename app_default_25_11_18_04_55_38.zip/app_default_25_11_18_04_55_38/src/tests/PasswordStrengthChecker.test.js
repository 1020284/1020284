import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import PasswordStrengthChecker from '../components/PasswordStrengthChecker';

describe('PasswordStrengthChecker component', () => {
  test('renders input and strength meter', () => {
    render(<PasswordStrengthChecker />);
    expect(screen.getByLabelText(/enter password/i)).toBeInTheDocument();
    expect(screen.getByRole('progressbar')).toBeInTheDocument();
  });

  test('updates strength meter for weak password', () => {
    render(<PasswordStrengthChecker />);
    const input = screen.getByLabelText(/enter password/i);
    fireEvent.change(input, { target: { value: 'abc' } });
    expect(screen.getByText(/weak/i)).toBeInTheDocument();
  });

  test('updates strength meter for strong password', () => {
    render(<PasswordStrengthChecker />);
    const input = screen.getByLabelText(/enter password/i);
    fireEvent.change(input, { target: { value: 'Abcdef1!' } });
    expect(screen.getByText(/strong/i)).toBeInTheDocument();
  });

  test('shows feedback messages', () => {
    render(<PasswordStrengthChecker />);
    const input = screen.getByLabelText(/enter password/i);
    fireEvent.change(input, { target: { value: 'aaaaaa' } });
    expect(screen.getByText(/avoid repeated characters/i)).toBeInTheDocument();
  });
});
