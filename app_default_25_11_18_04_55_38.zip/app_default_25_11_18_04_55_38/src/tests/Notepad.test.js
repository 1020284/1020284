import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import Notepad from '../components/Notepad';

const STORAGE_KEY = 'learningHubNotes';

describe('Notepad component', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  test('renders textarea and buttons', () => {
    render(<Notepad />);
    expect(screen.getByLabelText(/enter your notes/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /save/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /load/i })).toBeInTheDocument();
  });

  test('typing updates textarea value', () => {
    render(<Notepad />);
    const textarea = screen.getByLabelText(/enter your notes/i);
    fireEvent.change(textarea, { target: { value: 'Test note' } });
    expect(textarea).toHaveValue('Test note');
  });

  test('save button stores notes to localStorage', () => {
    render(<Notepad />);
    const textarea = screen.getByLabelText(/enter your notes/i);
    const saveBtn = screen.getByRole('button', { name: /save/i });
    fireEvent.change(textarea, { target: { value: 'Save this note' } });
    window.alert = jest.fn();
    fireEvent.click(saveBtn);
    expect(localStorage.getItem(STORAGE_KEY)).toBe('Save this note');
    expect(window.alert).toHaveBeenCalledWith('Note saved successfully.');
  });

  test('load button loads notes from localStorage', () => {
    localStorage.setItem(STORAGE_KEY, 'Loaded note');
    render(<Notepad />);
    const textarea = screen.getByLabelText(/enter your notes/i);
    const loadBtn = screen.getByRole('button', { name: /load/i });
    window.alert = jest.fn();
    fireEvent.click(loadBtn);
    expect(textarea).toHaveValue('Loaded note');
    expect(window.alert).toHaveBeenCalledWith('Note loaded successfully.');
  });
});
