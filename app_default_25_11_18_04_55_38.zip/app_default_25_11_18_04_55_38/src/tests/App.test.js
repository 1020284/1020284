import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import App from '../App';

describe('App component', () => {
  test('renders header and navigation buttons', () => {
    render(<App />);
    expect(screen.getByRole('banner')).toBeInTheDocument();
    expect(screen.getByRole('navigation')).toBeInTheDocument();
    expect(screen.getByText('Learning Hub')).toBeInTheDocument();
    expect(screen.getByRole('main')).toBeInTheDocument();

    // Navigation buttons
    const buttons = screen.getAllByRole('button');
    expect(buttons.length).toBeGreaterThanOrEqual(11);
  });

  test('navigation changes active utility component', () => {
    render(<App />);
    const calculatorButton = screen.getByRole('button', { name: /Calculator/i });
    fireEvent.click(calculatorButton);
    expect(screen.getByLabelText('Calculator')).toBeInTheDocument();

    const notepadButton = screen.getByRole('button', { name: /Notepad/i });
    fireEvent.click(notepadButton);
    expect(screen.getByLabelText('Notepad')).toBeInTheDocument();
  });

  test('spiderweb canvas is present and aria-hidden', () => {
    render(<App />);
    const canvas = document.querySelector('canvas');
    expect(canvas).toBeInTheDocument();
    expect(canvas).toHaveAttribute('aria-hidden', 'true');
  });
});
