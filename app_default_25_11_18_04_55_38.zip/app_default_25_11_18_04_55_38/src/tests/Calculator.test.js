import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import Calculator from '../components/Calculator';

describe('Calculator component', () => {
  beforeEach(() => {
    render(<Calculator />);
  });

  test('renders input and buttons', () => {
    expect(screen.getByRole('textbox')).toBeInTheDocument();
    ['7', '8', '9', '/', '4', '5', '6', '*', '1', '2', '3', '-', '0', '.', 'C', '+', '='].forEach((btn) => {
      expect(screen.getByRole('button', { name: new RegExp(btn) })).toBeInTheDocument();
    });
  });

  test('performs addition correctly', () => {
    fireEvent.click(screen.getByRole('button', { name: 'Input 1' }));
    fireEvent.click(screen.getByRole('button', { name: 'Input +' }));
    fireEvent.click(screen.getByRole('button', { name: 'Input 2' }));
    fireEvent.click(screen.getByRole('button', { name: 'Equals' }));
    expect(screen.getByRole('textbox')).toHaveValue('3');
  });

  test('handles division by zero gracefully', () => {
    fireEvent.click(screen.getByRole('button', { name: 'Input 1' }));
    fireEvent.click(screen.getByRole('button', { name: 'Input /' }));
    fireEvent.click(screen.getByRole('button', { name: 'Input 0' }));
    fireEvent.click(screen.getByRole('button', { name: 'Equals' }));
    expect(screen.getByRole('textbox')).toHaveValue('Error');
  });

  test('clear button clears input', () => {
    fireEvent.click(screen.getByRole('button', { name: 'Input 5' }));
    fireEvent.click(screen.getByRole('button', { name: 'Clear' }));
    expect(screen.getByRole('textbox')).toHaveValue('');
  });

  test('keyboard input works', () => {
    const input = screen.getByRole('textbox');
    fireEvent.keyDown(input, { key: '1' });
    fireEvent.keyDown(input, { key: '+' });
    fireEvent.keyDown(input, { key: '1' });
    fireEvent.keyDown(input, { key: 'Enter' });
    expect(input).toHaveValue('2');
  });
});
