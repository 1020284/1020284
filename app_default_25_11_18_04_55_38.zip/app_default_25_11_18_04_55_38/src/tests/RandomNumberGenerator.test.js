import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import RandomNumberGenerator from '../components/RandomNumberGenerator';

describe('RandomNumberGenerator component', () => {
  test('renders inputs and button', () => {
    render(<RandomNumberGenerator />);
    expect(screen.getByLabelText(/min/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/max/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /generate/i })).toBeInTheDocument();
  });

  test('shows error for invalid inputs', () => {
    render(<RandomNumberGenerator />);
    fireEvent.change(screen.getByLabelText(/min/i), { target: { value: 'abc' } });
    fireEvent.change(screen.getByLabelText(/max/i), { target: { value: '10' } });
    fireEvent.click(screen.getByRole('button', { name: /generate/i }));
    expect(screen.getByRole('alert')).toHaveTextContent('Please enter valid numbers.');
  });

  test('shows error if min > max', () => {
    render(<RandomNumberGenerator />);
    fireEvent.change(screen.getByLabelText(/min/i), { target: { value: '20' } });
    fireEvent.change(screen.getByLabelText(/max/i), { target: { value: '10' } });
    fireEvent.click(screen.getByRole('button', { name: /generate/i }));
    expect(screen.getByRole('alert')).toHaveTextContent('Minimum must be less than or equal to maximum.');
  });

  test('generates number within range', () => {
    render(<RandomNumberGenerator />);
    fireEvent.change(screen.getByLabelText(/min/i), { target: { value: '5' } });
    fireEvent.change(screen.getByLabelText(/max/i), { target: { value: '10' } });
    fireEvent.click(screen.getByRole('button', { name: /generate/i }));
    const text = screen.getByText(/Result:/i).textContent;
    const num = Number(text.replace(/Result:\s*/, ''));
    expect(num).toBeGreaterThanOrEqual(5);
    expect(num).toBeLessThanOrEqual(10);
  });
});
