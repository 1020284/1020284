import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import MarkdownPreview from '../components/MarkdownPreview';

describe('MarkdownPreview component', () => {
  test('renders input and preview pane', () => {
    render(<MarkdownPreview />);
    expect(screen.getByLabelText(/markdown input/i)).toBeInTheDocument();
    expect(screen.getByRole('region', { name: /markdown preview/i })).toBeFalsy(); // no region but preview div present
  });

  test('updates preview on input change', () => {
    render(<MarkdownPreview />);
    const textarea = screen.getByLabelText(/markdown input/i);
    fireEvent.change(textarea, { target: { value: '# Heading\n\n- item1\n- item2' } });
    expect(screen.getByText('Heading')).toBeInTheDocument();
    expect(screen.getByText('item1')).toBeInTheDocument();
    expect(screen.getByText('item2')).toBeInTheDocument();
  });

  test('renders links correctly', () => {
    render(<MarkdownPreview />);
    const textarea = screen.getByLabelText(/markdown input/i);
    fireEvent.change(textarea, { target: { value: '[React](https://reactjs.org)' } });
    const link = screen.getByRole('link', { name: /React/i });
    expect(link).toHaveAttribute('href', 'https://reactjs.org');
  });
});
