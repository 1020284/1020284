import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import UnitConverter from '../components/UnitConverter';

describe('UnitConverter component', () => {
  test('renders dropdown and inputs', () => {
    render(<UnitConverter />);
    expect(screen.getByLabelText(/Conversion Type/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Input \(cm\)/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Output \(in\)/i)).toBeInTheDocument();
  });

  test('converts cm to inches correctly', () => {
    render(<UnitConverter />);
    const input = screen.getByLabelText(/Input \(cm\)/i);
    fireEvent.change(input, { target: { value: '10' } });
    const output = screen.getByLabelText(/Output \(in\)/i);
    expect(parseFloat(output.value)).toBeCloseTo(3.937, 3);
  });

  test('swapping units works', () => {
    render(<UnitConverter />);
    const swapButton = screen.getByRole('button', { name: /swap units/i });
    fireEvent.click(swapButton);
    expect(screen.getByLabelText(/Input \(in\)/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Output \(cm\)/i)).toBeInTheDocument();
  });

  test('converts kg to pounds correctly', () => {
    render(<UnitConverter />);
    const select = screen.getByLabelText(/Conversion Type/i);
    fireEvent.change(select, { target: { value: 'kg-lb' } });
    const input = screen.getByLabelText(/Input \(kg\)/i);
    fireEvent.change(input, { target: { value: '2' } });
    const output = screen.getByLabelText(/Output \(lb\)/i);
    expect(parseFloat(output.value)).toBeCloseTo(4.409, 3);
  });
});
