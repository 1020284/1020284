import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import LoremIpsumGenerator from '../components/LoremIpsumGenerator';

describe('LoremIpsumGenerator component', () => {
  test('renders input and generate button', () => {
    render(<LoremIpsumGenerator />);
    expect(screen.getByLabelText(/number of paragraphs/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /generate/i })).toBeInTheDocument();
  });

  test('generates correct number of paragraphs', () => {
    render(<LoremIpsumGenerator />);
    const input = screen.getByLabelText(/number of paragraphs/i);
    fireEvent.change(input, { target: { value: '2' } });
    fireEvent.click(screen.getByRole('button', { name: /generate/i }));
    const paragraphs = screen.getAllByText(/Lorem ipsum|Ut enim|Duis aute|Excepteur/i);
    expect(paragraphs.length).toBe(2);
  });

  test('shows alert for invalid input', () => {
    window.alert = jest.fn();
    render(<LoremIpsumGenerator />);
    const input = screen.getByLabelText(/number of paragraphs/i);
    fireEvent.change(input, { target: { value: '20' } });
    fireEvent.click(screen.getByRole('button', { name: /generate/i }));
    expect(window.alert).toHaveBeenCalledWith('Please enter a valid number between 1 and 10.');
  });
});
