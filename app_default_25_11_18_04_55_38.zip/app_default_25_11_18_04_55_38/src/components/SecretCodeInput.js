import React, { useState, useEffect, useRef } from 'react';

const secretCombinations = {
  'Shift+B': () => alert('Secret code Shift+B detected!'),
  'Shift+D': () => alert('Secret code Shift+D detected!'),
  'Shift+S': () => alert('Secret code Shift+S detected!'),
  'Shift+L': () => alert('Secret code Shift+L detected!'),
  'Shift+M': () => alert('Secret code Shift+M detected!')
};

const SecretCodeInput = () => {
  const [inputValue, setInputValue] = useState('');
  const inputRef = useRef(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleKeyDown = (e) => {
    const combo = [];
    if (e.shiftKey) combo.push('Shift');
    if (e.ctrlKey) combo.push('Control');
    if (e.altKey) combo.push('Alt');
    if (e.metaKey) combo.push('Meta');

    // Only interested in Shift + letter combos here
    const keyUpper = e.key.toUpperCase();
    if (combo.length === 1 && combo[0] === 'Shift' && keyUpper.length === 1 && /[A-Z]/.test(keyUpper)) {
      const comboStr = `Shift+${keyUpper}`;
      if (secretCombinations[comboStr]) {
        e.preventDefault();
        secretCombinations[comboStr]();
      }
    }
  };

  return (
    <section aria-label="Secret Code Input" style={{ maxWidth: 400, margin: '0 auto' }}>
      <label htmlFor="secret-code-input" style={{ display: 'block', marginBottom: '0.5rem' }}>
        Type secret key combinations (e.g., Shift+B, Shift+D):
      </label>
      <input
        id="secret-code-input"
        type="text"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Press secret shortcuts here"
        ref={inputRef}
        aria-describedby="secret-instructions"
        style={{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: '1px solid var(--color-border)', backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}
        spellCheck={false}
        autoComplete="off"
        autoCorrect="off"
        autoCapitalize="off"
      />
      <p id="secret-instructions" style={{ marginTop: '0.5rem', fontSize: '0.875rem', color: 'var(--color-muted)' }}>
        Try pressing Shift+B, Shift+D, Shift+S, Shift+L, or Shift+M to reveal secret alerts.
      </p>
    </section>
  );
};

export default SecretCodeInput;
