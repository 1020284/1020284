import React, { useEffect, useState } from 'react';
import { format } from 'date-fns';

const CurrentTime = () => {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const timerId = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timerId);
  }, []);

  return (
    <section aria-label="Current Time" className="current-time" style={{ textAlign: 'center', fontSize: '2rem' }}>
      <p tabIndex={0} aria-live="polite" aria-atomic="true">{format(now, 'HH:mm:ss')}</p>
    </section>
  );
};

export default CurrentTime;
