import React, { useState, useEffect, useRef } from 'react';

const buttons = [
  ['7', '8', '9', '/'],
  ['4', '5', '6', '*'],
  ['1', '2', '3', '-'],
  ['0', '.', 'C', '+'],
  ['=']
];

const isOperator = (char) => ['+', '-', '*', '/'].includes(char);

const Calculator = () => {
  const [expression, setExpression] = useState('');
  const inputRef = useRef(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const appendChar = (char) => {
    setExpression((prev) => {
      if (char === '.' && prev.endsWith('.')) return prev;
      if (isOperator(char)) {
        if (prev === '' && char !== '-') return prev; // disallow operator first except minus
        if (isOperator(prev.slice(-1))) return prev.slice(0, -1) + char; // replace last operator
      }
      return prev + char;
    });
  };

  const calculate = () => {
    if (expression === '') return;
    try {
      // eslint-disable-next-line no-eval
      // Use Function constructor for safer evaluation
      // But here we sanitize input to only allow numbers/operators
      const sanitized = expression.replace(/[^-()\d/*+.]/g, '');
      // eslint-disable-next-line no-new-func
      const result = new Function(`return ${sanitized}`)();
      if (typeof result === 'number' && !Number.isNaN(result) && Number.isFinite(result)) {
        setExpression(String(result));
      } else {
        setExpression('Error');
      }
    } catch {
      setExpression('Error');
    }
  };

  const clear = () => setExpression('');

  const handleButtonClick = (char) => {
    if (char === 'C') clear();
    else if (char === '=') calculate();
    else appendChar(char);
  };

  const handleKeyDown = (event) => {
    const { key } = event;
    if (key === 'Enter' || key === '=') {
      event.preventDefault();
      calculate();
    } else if (key === 'Backspace') {
      event.preventDefault();
      setExpression((prev) => prev.slice(0, -1));
    } else if (key === 'c' || key === 'C') {
      event.preventDefault();
      clear();
    } else if (
      /^[0-9+\-*/.=]$/.test(key)
    ) {
      event.preventDefault();
      if (key === '=') calculate();
      else appendChar(key === '.' ? '.' : key);
    }
  };

  return (
    <section aria-label="Calculator" className="calculator" style={{ maxWidth: 320, margin: '0 auto' }}>
      <input
        type="text"
        aria-label="Calculator input"
        role="textbox"
        value={expression}
        ref={inputRef}
        onChange={(e) => setExpression(e.target.value)}
        onKeyDown={handleKeyDown}
        spellCheck={false}
        autoComplete="off"
        autoCorrect="off"
        autoCapitalize="off"
        inputMode="decimal"
        style={{ width: '100%', fontSize: '1.5rem', padding: '0.5rem', textAlign: 'right', backgroundColor: 'var(--color-bg)', color: 'var(--color-text)', border: '1px solid var(--color-border)', borderRadius: '4px', marginBottom: '0.75rem' }}
      />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '0.5rem' }}>
        {buttons.flat().map((btn) => (
          <button
            key={btn}
            type="button"
            onClick={() => handleButtonClick(btn)}
            aria-label={btn === 'C' ? 'Clear' : btn === '=' ? 'Equals' : `Input ${btn}`}
            style={{ padding: '0.75rem 0', fontSize: '1.25rem', borderRadius: '4px', userSelect: 'none' }}
          >
            {btn}
          </button>
        ))}
      </div>
    </section>
  );
};

export default Calculator;
