import React, { useState } from 'react';

const LOREM_IPSUM_PARAGRAPHS = [
  `Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.`,
  `Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.`,
  `Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.`,
  `Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.`,
  `Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.`,
  `Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.`,
  `Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit.`,
  `Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit.`,
  `Sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.`,
  `Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur?`
];

const LoremIpsumGenerator = () => {
  const [paragraphCount, setParagraphCount] = useState('3');
  const [output, setOutput] = useState([]);

  const generate = () => {
    const count = parseInt(paragraphCount, 10);
    if (Number.isNaN(count) || count < 1 || count > 10) {
      alert('Please enter a valid number between 1 and 10.');
      return;
    }
    setOutput(LOREM_IPSUM_PARAGRAPHS.slice(0, count));
  };

  return (
    <section aria-label="Lorem Ipsum Generator" style={{ maxWidth: 600, margin: '0 auto' }}>
      <label htmlFor="lorem-count" style={{ display: 'block', marginBottom: '0.5rem' }}>
        Number of paragraphs (1-10):
      </label>
      <input
        id="lorem-count"
        type="number"
        value={paragraphCount}
        onChange={(e) => setParagraphCount(e.target.value)}
        min="1"
        max="10"
        aria-label="Number of paragraphs"
        style={{ width: '100%', marginBottom: '0.75rem', padding: '0.5rem', borderRadius: '4px', border: '1px solid var(--color-border)', backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}
      />
      <button type="button" onClick={generate} style={{ width: '100%', marginBottom: '1rem' }}>
        Generate
      </button>
      <div
        aria-live="polite"
        aria-atomic="true"
        style={{ maxHeight: '300px', overflowY: 'auto', padding: '0.5rem', backgroundColor: 'var(--color-bg-alt)', borderRadius: '4px', border: '1px solid var(--color-border)', color: 'var(--color-text)', lineHeight: '1.6' }}
      >
        {output.length === 0 && <p>No text generated yet.</p>}
        {output.map((para, i) => (
          <p key={`lorem-${i}`} style={{ marginTop: i === 0 ? 0 : '1rem' }}>
            {para}
          </p>
        ))}
      </div>
    </section>
  );
};

export default LoremIpsumGenerator;
