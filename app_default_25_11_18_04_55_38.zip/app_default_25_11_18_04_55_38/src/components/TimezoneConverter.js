import React, { useState, useEffect } from 'react';
import { format, utcToZonedTime, zonedTimeToUtc } from 'date-fns-tz';

const timezones = [
  'UTC',
  'America/New_York',
  'America/Chicago',
  'America/Denver',
  'America/Los_Angeles',
  'Europe/London',
  'Europe/Paris',
  'Europe/Berlin',
  'Asia/Tokyo',
  'Asia/Shanghai',
  'Asia/Kolkata',
  'Australia/Sydney'
];

const TimezoneConverter = () => {
  const [datetime, setDatetime] = useState(() => {
    // format as yyyy-MM-ddThh:mm for input[type=datetime-local]
    const now = new Date();
    const pad = (n) => (n < 10 ? `0${n}` : n);
    return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}T${pad(now.getHours())}:${pad(now.getMinutes())}`;
  });
  const [sourceTZ, setSourceTZ] = useState('UTC');
  const [targetTZ, setTargetTZ] = useState('America/New_York');
  const [converted, setConverted] = useState('');
  const [error, setError] = useState(null);

  useEffect(() => {
    setError(null);
    if (!datetime) {
      setConverted('');
      return;
    }
    try {
      const sourceDate = new Date(datetime);
      if (Number.isNaN(sourceDate.getTime())) {
        setError('Invalid date/time');
        setConverted('');
        return;
      }
      // Convert source datetime in sourceTZ to UTC
      const utcDate = zonedTimeToUtc(sourceDate, sourceTZ);
      // Convert UTC date to target timezone
      const targetDate = utcToZonedTime(utcDate, targetTZ);
      // Format for display
      const formatted = format(targetDate, 'yyyy-MM-dd HH:mm:ssXXX', { timeZone: targetTZ });
      setConverted(formatted);
    } catch {
      setError('Conversion error');
      setConverted('');
    }
  }, [datetime, sourceTZ, targetTZ]);

  return (
    <section aria-label="Timezone Converter" style={{ maxWidth: 480, margin: '0 auto' }}>
      <label htmlFor="datetime-input" style={{ display: 'block', marginBottom: '0.25rem' }}>
        Enter date and time:
      </label>
      <input
        id="datetime-input"
        type="datetime-local"
        value={datetime}
        onChange={(e) => setDatetime(e.target.value)}
        aria-invalid={!!error}
        aria-describedby="tz-error"
        style={{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: '1px solid var(--color-border)', backgroundColor: 'var(--color-bg)', color: 'var(--color-text)', marginBottom: '0.75rem' }}
      />
      <label htmlFor="source-tz" style={{ display: 'block', marginBottom: '0.25rem' }}>
        Source Timezone:
      </label>
      <select
        id="source-tz"
        value={sourceTZ}
        onChange={(e) => setSourceTZ(e.target.value)}
        style={{ width: '100%', marginBottom: '0.75rem' }}
        aria-label="Select source timezone"
      >
        {timezones.map((tz) => (
          <option key={tz} value={tz}>
            {tz}
          </option>
        ))}
      </select>
      <label htmlFor="target-tz" style={{ display: 'block', marginBottom: '0.25rem' }}>
        Target Timezone:
      </label>
      <select
        id="target-tz"
        value={targetTZ}
        onChange={(e) => setTargetTZ(e.target.value)}
        style={{ width: '100%', marginBottom: '1rem' }}
        aria-label="Select target timezone"
      >
        {timezones.map((tz) => (
          <option key={tz} value={tz}>
            {tz}
          </option>
        ))}
      </select>
      {error && (
        <p id="tz-error" role="alert" style={{ color: 'var(--color-error)', marginBottom: '0.5rem' }}>
          {error}
        </p>
      )}
      {converted && !error && (
        <p aria-live="polite" style={{ fontWeight: 'bold' }}>
          Converted time: {converted}
        </p>
      )}
    </section>
  );
};

export default TimezoneConverter;
