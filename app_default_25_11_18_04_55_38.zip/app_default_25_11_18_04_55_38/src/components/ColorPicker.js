import React, { useState } from 'react';

const ColorPicker = () => {
  const [color, setColor] = useState('#0d99ff');

  return (
    <section aria-label="Color Picker" style={{ maxWidth: 280, margin: '0 auto', textAlign: 'center' }}>
      <label htmlFor="color-input" style={{ display: 'block', marginBottom: '0.5rem' }}>
        Select a color:
      </label>
      <input
        id="color-input"
        type="color"
        value={color}
        onChange={(e) => setColor(e.target.value)}
        aria-label="Color picker input"
        style={{ width: '100%', height: '3rem', border: 'none', cursor: 'pointer', backgroundColor: 'transparent' }}
      />
      <div
        aria-live="polite"
        aria-atomic="true"
        style={{
          marginTop: '1rem',
          fontWeight: 'bold',
          fontSize: '1.25rem',
          color,
          userSelect: 'none'
        }}
      >
        Selected Color: {color.toUpperCase()}
      </div>
      <div
        aria-hidden="true"
        style={{
          marginTop: '1rem',
          height: '60px',
          width: '100%',
          backgroundColor: color,
          borderRadius: '8px',
          border: '1px solid var(--color-border)'
        }}
      />
    </section>
  );
};

export default ColorPicker;
