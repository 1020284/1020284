import React, { useState, useEffect } from 'react';

const conversionTypes = [
  { id: 'cm-in', label: 'Centimeters ↔ Inches' },
  { id: 'kg-lb', label: 'Kilograms ↔ Pounds' }
];

const UnitConverter = () => {
  const [type, setType] = useState('cm-in');
  const [inputValue, setInputValue] = useState('');
  const [inputUnit, setInputUnit] = useState('cm');
  const [outputValue, setOutputValue] = useState('');
  const [outputUnit, setOutputUnit] = useState('in');

  useEffect(() => {
    setInputValue('');
    setOutputValue('');
    if (type === 'cm-in') {
      setInputUnit('cm');
      setOutputUnit('in');
    } else {
      setInputUnit('kg');
      setOutputUnit('lb');
    }
  }, [type]);

  useEffect(() => {
    if (inputValue === '' || Number.isNaN(Number(inputValue))) {
      setOutputValue('');
      return;
    }
    const val = Number(inputValue);
    let converted = null;
    switch (type) {
      case 'cm-in':
        if (inputUnit === 'cm') converted = val / 2.54;
        else converted = val * 2.54;
        break;
      case 'kg-lb':
        if (inputUnit === 'kg') converted = val * 2.2046226218;
        else converted = val / 2.2046226218;
        break;
      default:
        converted = '';
    }
    setOutputValue(converted !== null ? converted.toFixed(4) : '');
  }, [inputValue, inputUnit, type]);

  const swapUnits = () => {
    setInputUnit(outputUnit);
    setOutputUnit(inputUnit);
    setInputValue(outputValue);
  };

  return (
    <section aria-label="Unit Converter" style={{ maxWidth: 400, margin: '0 auto' }}>
      <label htmlFor="conversion-type" style={{ display: 'block', marginBottom: '0.5rem' }}>
        Conversion Type:
      </label>
      <select
        id="conversion-type"
        value={type}
        onChange={(e) => setType(e.target.value)}
        aria-label="Select conversion type"
        style={{ width: '100%', marginBottom: '1rem' }}
      >
        {conversionTypes.map(({ id, label }) => (
          <option key={id} value={id}>
            {label}
          </option>
        ))}
      </select>
      <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center', marginBottom: '1rem' }}>
        <label htmlFor="input-value" style={{ flex: 1 }}>
          Input ({inputUnit}):
          <input
            id="input-value"
            type="number"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            inputMode="decimal"
            style={{ width: '100%' }}
            aria-label={`Input value in ${inputUnit}`}
          />
        </label>
        <button
          type="button"
          onClick={swapUnits}
          aria-label="Swap units"
          style={{
            flexShrink: 0,
            padding: '0.5rem',
            fontSize: '1.25rem',
            cursor: 'pointer',
            borderRadius: '4px'
          }}
        >
          ⇄
        </button>
        <label htmlFor="output-value" style={{ flex: 1 }}>
          Output ({outputUnit}):
          <input
            id="output-value"
            type="text"
            value={outputValue}
            readOnly
            aria-readonly="true"
            style={{ width: '100%', backgroundColor: 'var(--color-bg-alt)', color: 'var(--color-text)', border: '1px solid var(--color-border)', borderRadius: '4px', padding: '0.5rem' }}
          />
        </label>
      </div>
    </section>
  );
};

export default UnitConverter;
