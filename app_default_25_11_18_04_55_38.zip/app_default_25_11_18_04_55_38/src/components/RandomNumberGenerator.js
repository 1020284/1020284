import React, { useState } from 'react';

const RandomNumberGenerator = () => {
  const [min, setMin] = useState('');
  const [max, setMax] = useState('');
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const generate = () => {
    setError(null);
    const parsedMin = Number(min);
    const parsedMax = Number(max);

    if (Number.isNaN(parsedMin) || Number.isNaN(parsedMax)) {
      setError('Please enter valid numbers.');
      setResult(null);
      return;
    }
    if (parsedMin > parsedMax) {
      setError('Minimum must be less than or equal to maximum.');
      setResult(null);
      return;
    }
    const randomInt = Math.floor(Math.random() * (parsedMax - parsedMin + 1)) + parsedMin;
    setResult(randomInt);
  };

  return (
    <section aria-label="Random Number Generator" style={{ maxWidth: 320, margin: '0 auto' }}>
      <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
        <label htmlFor="rng-min" style={{ flex: '1 1 45%' }}>
          Min:
          <input
            id="rng-min"
            type="number"
            value={min}
            onChange={(e) => setMin(e.target.value)}
            aria-describedby="rng-error"
            aria-invalid={!!error}
            style={{ width: '100%' }}
          />
        </label>
        <label htmlFor="rng-max" style={{ flex: '1 1 45%' }}>
          Max:
          <input
            id="rng-max"
            type="number"
            value={max}
            onChange={(e) => setMax(e.target.value)}
            aria-describedby="rng-error"
            aria-invalid={!!error}
            style={{ width: '100%' }}
          />
        </label>
      </div>
      <button type="button" onClick={generate} style={{ marginTop: '0.75rem', width: '100%' }}>
        Generate
      </button>
      {error && (
        <p id="rng-error" role="alert" style={{ color: 'var(--color-error)', marginTop: '0.5rem' }}>
          {error}
        </p>
      )}
      {result !== null && !error && (
        <p aria-live="polite" style={{ marginTop: '0.5rem', fontWeight: 'bold', fontSize: '1.25rem' }}>
          Result: {result}
        </p>
      )}
    </section>
  );
};

export default RandomNumberGenerator;
