import React, { useState, useEffect } from 'react';

const STORAGE_KEY = 'learningHubNotes';

const Notepad = () => {
  const [note, setNote] = useState('');

  useEffect(() => {
    try {
      const savedNote = localStorage.getItem(STORAGE_KEY);
      if (savedNote) setNote(savedNote);
    } catch {
      // Ignore localStorage errors silently
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, note);
    } catch {
      // Ignore write errors silently
    }
  }, [note]);

  const handleSave = () => {
    try {
      localStorage.setItem(STORAGE_KEY, note);
      alert('Note saved successfully.');
    } catch {
      alert('Error saving note.');
    }
  };

  const handleLoad = () => {
    try {
      const savedNote = localStorage.getItem(STORAGE_KEY);
      if (savedNote !== null) {
        setNote(savedNote);
        alert('Note loaded successfully.');
      } else {
        alert('No saved note found.');
      }
    } catch {
      alert('Error loading note.');
    }
  };

  return (
    <section aria-label="Notepad">
      <label htmlFor="notepad-textarea" style={{ display: 'block', marginBottom: '0.5rem' }}>
        Enter your notes:
      </label>
      <textarea
        id="notepad-textarea"
        value={note}
        onChange={(e) => setNote(e.target.value)}
        rows={15}
        style={{ width: '100%', fontFamily: 'inherit', fontSize: '1rem', padding: '0.5rem', borderRadius: '4px', border: '1px solid var(--color-border)', backgroundColor: 'var(--color-bg)', color: 'var(--color-text)', resize: 'vertical' }}
        aria-multiline="true"
        spellCheck={true}
      />
      <div style={{ marginTop: '0.75rem', display: 'flex', gap: '1rem' }}>
        <button type="button" onClick={handleSave} aria-label="Save notes">
          Save
        </button>
        <button type="button" onClick={handleLoad} aria-label="Load saved notes">
          Load
        </button>
      </div>
    </section>
  );
};

export default Notepad;
