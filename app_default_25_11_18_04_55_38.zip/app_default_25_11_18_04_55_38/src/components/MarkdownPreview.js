import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';

const MarkdownPreview = () => {
  const [markdown, setMarkdown] = useState(
`# Welcome to Markdown Preview!

Type your **Markdown** here and see the preview on the right.

## Features:

- Headings
- **Bold** and _italic_ text
- Lists
- [Links](https://reactjs.org)
- \`Code\` blocks
`
  );

  return (
    <section aria-label="Markdown Preview" style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
      <div style={{ flex: '1 1 45%', minWidth: 280, display: 'flex', flexDirection: 'column' }}>
        <label htmlFor="markdown-input" style={{ marginBottom: '0.5rem' }}>
          Markdown Input:
        </label>
        <textarea
          id="markdown-input"
          value={markdown}
          onChange={(e) => setMarkdown(e.target.value)}
          rows={15}
          style={{ width: '100%', fontFamily: 'inherit', fontSize: '1rem', padding: '0.5rem', borderRadius: '4px', border: '1px solid var(--color-border)', backgroundColor: 'var(--color-bg)', color: 'var(--color-text)', resize: 'vertical' }}
          spellCheck={false}
          aria-multiline="true"
        />
      </div>
      <div
        aria-live="polite"
        aria-atomic="true"
        style={{
          flex: '1 1 45%',
          minWidth: 280,
          backgroundColor: 'var(--color-bg-alt)',
          borderRadius: '4px',
          padding: '0.75rem',
          overflowY: 'auto',
          maxHeight: 420,
          color: 'var(--color-text)',
          boxShadow: 'inset 0 0 8px rgba(0,0,0,0.8)'
        }}
      >
        <ReactMarkdown>{markdown}</ReactMarkdown>
      </div>
    </section>
  );
};

export default MarkdownPreview;
