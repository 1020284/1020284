import React, { useState } from 'react';

const calculateStrength = (password) => {
  if (!password) return { score: 0, feedback: 'Enter a password' };

  let score = 0;
  let feedback = [];

  const length = password.length;

  // Length points
  if (length >= 8) score += 1;
  if (length >= 12) score += 1;
  if (length >= 16) score += 1;

  // Contains lowercase
  if (/[a-z]/.test(password)) score += 1;
  else feedback.push('Add lowercase letters');

  // Contains uppercase
  if (/[A-Z]/.test(password)) score += 1;
  else feedback.push('Add uppercase letters');

  // Contains digits
  if (/\d/.test(password)) score += 1;
  else feedback.push('Add digits');

  // Contains special chars
  if (/[^A-Za-z0-9]/.test(password)) score += 1;
  else feedback.push('Add special characters');

  // Repeated chars penalty
  if (/(\w)\1{2,}/.test(password)) {
    score = Math.max(score - 1, 0);
    feedback.push('Avoid repeated characters');
  }

  let strengthLabel = 'Very Weak';
  if (score >= 7) strengthLabel = 'Very Strong';
  else if (score >= 5) strengthLabel = 'Strong';
  else if (score >= 3) strengthLabel = 'Moderate';
  else if (score >= 1) strengthLabel = 'Weak';

  const feedbackText = feedback.length > 0 ? feedback.join(', ') : 'Good password';

  return { score, strengthLabel, feedbackText };
};

const PasswordStrengthChecker = () => {
  const [password, setPassword] = useState('');
  const { score, strengthLabel, feedbackText } = calculateStrength(password);

  const strengthPercent = (score / 7) * 100;

  const getBarColor = () => {
    if (score >= 6) return 'var(--color-success)';
    if (score >= 4) return '#ffb300'; // amber
    if (score >= 2) return '#ff6f00'; // orange dark
    return 'var(--color-error)';
  };

  return (
    <section aria-label="Password Strength Checker" style={{ maxWidth: 480, margin: '0 auto' }}>
      <label htmlFor="password-input" style={{ display: 'block', marginBottom: '0.5rem' }}>
        Enter password:
      </label>
      <input
        id="password-input"
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        aria-describedby="password-strength feedback-text"
        style={{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: '1px solid var(--color-border)', backgroundColor: 'var(--color-bg)', color: 'var(--color-text)', marginBottom: '0.75rem' }}
        autoComplete="new-password"
        spellCheck={false}
      />
      <div
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={Math.round(strengthPercent)}
        aria-label="Password strength meter"
        style={{
          height: 12,
          width: '100%',
          backgroundColor: 'var(--color-border)',
          borderRadius: 6,
          overflow: 'hidden',
          marginBottom: '0.5rem'
        }}
      >
        <div
          style={{
            height: '100%',
            width: `${strengthPercent}%`,
            backgroundColor: getBarColor(),
            transition: 'width 0.3s ease'
          }}
        />
      </div>
      <p id="password-strength" style={{ fontWeight: 'bold', marginBottom: '0.25rem' }}>
        Strength: {strengthLabel}
      </p>
      <p id="feedback-text" style={{ fontSize: '0.875rem', color: 'var(--color-muted)' }}>
        {feedbackText}
      </p>
    </section>
  );
};

export default PasswordStrengthChecker;
