import React, { useState } from 'react';
import SpiderwebBackground from './components/SpiderwebBackground';
import Calculator from './components/Calculator';
import CurrentTime from './components/CurrentTime';
import Notepad from './components/Notepad';
import RandomNumberGenerator from './components/RandomNumberGenerator';
import UnitConverter from './components/UnitConverter';
import SecretCodeInput from './components/SecretCodeInput';
import MarkdownPreview from './components/MarkdownPreview';
import TimezoneConverter from './components/TimezoneConverter';
import PasswordStrengthChecker from './components/PasswordStrengthChecker';
import ColorPicker from './components/ColorPicker';
import LoremIpsumGenerator from './components/LoremIpsumGenerator';

const utilities = [
  { id: 'calculator', label: 'Calculator', component: Calculator },
  { id: 'currentTime', label: 'Current Time', component: CurrentTime },
  { id: 'notepad', label: 'Notepad', component: Notepad },
  { id: 'randomNumber', label: 'Random Number Generator', component: RandomNumberGenerator },
  { id: 'unitConverter', label: 'Unit Converter', component: UnitConverter },
  { id: 'secretCode', label: 'Secret Code Input', component: SecretCodeInput },
  { id: 'markdownPreview', label: 'Markdown Preview', component: MarkdownPreview },
  { id: 'timezoneConverter', label: 'Timezone Converter', component: TimezoneConverter },
  { id: 'passwordChecker', label: 'Password Strength Checker', component: PasswordStrengthChecker },
  { id: 'colorPicker', label: 'Color Picker', component: ColorPicker },
  { id: 'loremIpsum', label: 'Lorem Ipsum Generator', component: LoremIpsumGenerator }
];

export default function App() {
  const [activeUtility, setActiveUtility] = useState('calculator');

  const ActiveComponent = utilities.find(u => u.id === activeUtility)?.component || (() => <div>Utility not found</div>);

  return (
    <div className="app">
      <SpiderwebBackground />
      <header className="header" role="banner">
        <h1 tabIndex={0}>Learning Hub</h1>
        <nav aria-label="Utility navigation">
          <ul className="nav-list">
            {utilities.map(({ id, label }) => (
              <li key={id}>
                <button
                  type="button"
                  className={`nav-button ${id === activeUtility ? 'active' : ''}`}
                  onClick={() => setActiveUtility(id)}
                  aria-current={id === activeUtility ? 'page' : undefined}
                >
                  {label}
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </header>
      <main className="main-content" role="main" tabIndex={-1}>
        <ActiveComponent />
      </main>
      <footer className="footer" role="contentinfo">
        <small>© 2024 Learning Hub. All rights reserved.</small>
      </footer>
    </div>
  );
}
